This is extremely crude ATM. I just took foo_catnap, fixed a bug, and added "seconds" and "seek" fields.
It should compile as-is, as I've included all dependencies.
While it compiles, go have a meal, take a visit to the local museum, dunno.

